// History Management for MCQ generations
class HistoryManager {
    constructor() {
        this.storageKey = 'mcq_generation_history';
        this.maxHistoryItems = 50; // Limit to prevent localStorage overflow
    }

    // Add a new generation to history
    addToHistory(generationData) {
        try {
            const history = this.getHistory();
            
            // Create history item with additional metadata
            const historyItem = {
                id: this.generateId(),
                fileName: generationData.fileName,
                difficulty: generationData.difficulty,
                questionCount: generationData.questionCount,
                mcqs: generationData.mcqs,
                summary: generationData.summary,
                timestamp: generationData.timestamp || new Date().toISOString(),
                fileSize: generationData.fileSize || null,
                processingTime: generationData.processingTime || null
            };

            // Add to beginning of array (most recent first)
            history.unshift(historyItem);

            // Trim history if it exceeds maximum items
            if (history.length > this.maxHistoryItems) {
                history.splice(this.maxHistoryItems);
            }

            this.saveHistory(history);
            return historyItem.id;
        } catch (error) {
            console.error('Failed to add item to history:', error);
            throw new Error('Failed to save generation to history');
        }
    }

    // Get all history items
    getHistory() {
        try {
            const storedHistory = localStorage.getItem(this.storageKey);
            if (!storedHistory) return [];
            
            const history = JSON.parse(storedHistory);
            return Array.isArray(history) ? history : [];
        } catch (error) {
            console.error('Failed to retrieve history:', error);
            return [];
        }
    }

    // Get a specific history item by ID
    getHistoryItem(id) {
        const history = this.getHistory();
        return history.find(item => item.id === id);
    }

    // Remove an item from history by index
    removeFromHistory(index) {
        try {
            const history = this.getHistory();
            if (index >= 0 && index < history.length) {
                history.splice(index, 1);
                this.saveHistory(history);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Failed to remove item from history:', error);
            return false;
        }
    }

    // Remove an item from history by ID
    removeFromHistoryById(id) {
        try {
            const history = this.getHistory();
            const index = history.findIndex(item => item.id === id);
            if (index !== -1) {
                history.splice(index, 1);
                this.saveHistory(history);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Failed to remove item from history:', error);
            return false;
        }
    }

    // Clear all history
    clearHistory() {
        try {
            localStorage.removeItem(this.storageKey);
            return true;
        } catch (error) {
            console.error('Failed to clear history:', error);
            return false;
        }
    }

    // Search history by filename or content
    searchHistory(query) {
        const history = this.getHistory();
        const lowercaseQuery = query.toLowerCase();
        
        return history.filter(item => {
            return item.fileName.toLowerCase().includes(lowercaseQuery) ||
                   item.summary.toLowerCase().includes(lowercaseQuery) ||
                   item.mcqs.some(mcq => 
                       mcq.question.toLowerCase().includes(lowercaseQuery)
                   );
        });
    }

    // Get history statistics
    getHistoryStats() {
        const history = this.getHistory();
        
        if (history.length === 0) {
            return {
                totalGenerations: 0,
                totalQuestions: 0,
                difficultyBreakdown: {},
                averageQuestions: 0,
                oldestGeneration: null,
                newestGeneration: null
            };
        }

        const stats = {
            totalGenerations: history.length,
            totalQuestions: history.reduce((sum, item) => sum + item.questionCount, 0),
            difficultyBreakdown: {},
            averageQuestions: 0,
            oldestGeneration: new Date(Math.min(...history.map(item => new Date(item.timestamp)))),
            newestGeneration: new Date(Math.max(...history.map(item => new Date(item.timestamp))))
        };

        // Calculate difficulty breakdown
        history.forEach(item => {
            const difficulty = item.difficulty;
            stats.difficultyBreakdown[difficulty] = (stats.difficultyBreakdown[difficulty] || 0) + 1;
        });

        // Calculate average questions per generation
        stats.averageQuestions = Math.round(stats.totalQuestions / stats.totalGenerations);

        return stats;
    }

    // Export history as JSON
    exportHistory() {
        try {
            const history = this.getHistory();
            const exportData = {
                exportDate: new Date().toISOString(),
                version: '1.0',
                totalItems: history.length,
                data: history
            };
            
            const blob = new Blob([JSON.stringify(exportData, null, 2)], { 
                type: 'application/json' 
            });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `mcq_history_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            return true;
        } catch (error) {
            console.error('Failed to export history:', error);
            return false;
        }
    }

    // Import history from JSON file
    async importHistory(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                try {
                    const importData = JSON.parse(e.target.result);
                    
                    // Validate import data structure
                    if (!importData.data || !Array.isArray(importData.data)) {
                        throw new Error('Invalid import file format');
                    }
                    
                    // Validate each history item
                    const validItems = importData.data.filter(item => {
                        return item.fileName && 
                               item.difficulty && 
                               item.questionCount && 
                               item.mcqs && 
                               item.timestamp;
                    });
                    
                    if (validItems.length === 0) {
                        throw new Error('No valid history items found in import file');
                    }
                    
                    // Merge with existing history
                    const existingHistory = this.getHistory();
                    const mergedHistory = [...validItems, ...existingHistory];
                    
                    // Remove duplicates based on timestamp and filename
                    const uniqueHistory = mergedHistory.filter((item, index, arr) => {
                        return arr.findIndex(other => 
                            other.timestamp === item.timestamp && 
                            other.fileName === item.fileName
                        ) === index;
                    });
                    
                    // Limit to max items
                    if (uniqueHistory.length > this.maxHistoryItems) {
                        uniqueHistory.splice(this.maxHistoryItems);
                    }
                    
                    this.saveHistory(uniqueHistory);
                    resolve({
                        imported: validItems.length,
                        total: uniqueHistory.length,
                        duplicatesRemoved: mergedHistory.length - uniqueHistory.length
                    });
                    
                } catch (error) {
                    reject(new Error(`Failed to import history: ${error.message}`));
                }
            };
            
            reader.onerror = () => {
                reject(new Error('Failed to read import file'));
            };
            
            reader.readAsText(file);
        });
    }

    // Private helper methods
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    saveHistory(history) {
        try {
            const serialized = JSON.stringify(history);
            
            // Check if data would exceed localStorage limit
            if (serialized.length > 5000000) { // ~5MB limit
                console.warn('History data is getting large, consider clearing old items');
                
                // Automatically remove oldest items if approaching limit
                const truncatedHistory = history.slice(0, Math.floor(this.maxHistoryItems * 0.8));
                localStorage.setItem(this.storageKey, JSON.stringify(truncatedHistory));
            } else {
                localStorage.setItem(this.storageKey, serialized);
            }
        } catch (error) {
            if (error.name === 'QuotaExceededError') {
                // Handle localStorage quota exceeded
                console.error('localStorage quota exceeded, clearing old history items');
                const reducedHistory = history.slice(0, Math.floor(this.maxHistoryItems * 0.5));
                try {
                    localStorage.setItem(this.storageKey, JSON.stringify(reducedHistory));
                } catch (retryError) {
                    console.error('Failed to save even reduced history:', retryError);
                    throw new Error('Unable to save history due to storage limitations');
                }
            } else {
                throw error;
            }
        }
    }

    // Method to get storage usage information
    getStorageInfo() {
        try {
            const history = this.getHistory();
            const serialized = JSON.stringify(history);
            
            return {
                itemCount: history.length,
                storageSize: serialized.length,
                storageSizeFormatted: this.formatBytes(serialized.length),
                maxItems: this.maxHistoryItems,
                isNearLimit: serialized.length > 4000000 // ~4MB warning threshold
            };
        } catch (error) {
            console.error('Failed to get storage info:', error);
            return null;
        }
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}
