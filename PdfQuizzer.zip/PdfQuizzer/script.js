// Main application logic
class MCQApp {
    constructor() {
        this.currentFile = null;
        this.extractedText = '';
        this.currentMCQs = null;
        this.currentSummary = '';
        
        this.initializeElements();
        this.attachEventListeners();
        this.initializePDFjs();
    }

    initializeElements() {
        // Upload elements
        this.uploadArea = document.getElementById('uploadArea');
        this.fileInput = document.getElementById('fileInput');
        this.browseBtn = document.getElementById('browseBtn');
        this.fileInfo = document.getElementById('fileInfo');
        this.fileName = document.getElementById('fileName');
        this.fileSize = document.getElementById('fileSize');
        this.removeFileBtn = document.getElementById('removeFile');

        // Configuration elements
        this.configSection = document.getElementById('configSection');
        this.difficulty = document.getElementById('difficulty');
        this.questionCount = document.getElementById('questionCount');
        this.generateBtn = document.getElementById('generateBtn');

        // Loading elements
        this.loadingSection = document.getElementById('loadingSection');
        this.loadingText = document.getElementById('loadingText');

        // Results elements
        this.resultsSection = document.getElementById('resultsSection');
        this.documentSummary = document.getElementById('documentSummary');
        this.mcqsContainer = document.getElementById('mcqsContainer');
        this.downloadBtn = document.getElementById('downloadBtn');
        this.newGenerationBtn = document.getElementById('newGenerationBtn');

        // History elements
        this.historyBtn = document.getElementById('historyBtn');
        this.historyModal = document.getElementById('historyModal');
        this.closeHistoryModal = document.getElementById('closeHistoryModal');
        this.historyList = document.getElementById('historyList');

        // Toast container
        this.toastContainer = document.getElementById('toastContainer');
    }

    initializePDFjs() {
        // Set PDF.js worker
        if (typeof pdfjsLib !== 'undefined') {
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
        }
    }

    attachEventListeners() {
        // File upload events
        this.browseBtn.addEventListener('click', () => this.fileInput.click());
        this.fileInput.addEventListener('change', (e) => this.handleFileSelect(e.target.files[0]));
        this.removeFileBtn.addEventListener('click', () => this.removeFile());

        // Drag and drop events
        this.uploadArea.addEventListener('dragover', (e) => this.handleDragOver(e));
        this.uploadArea.addEventListener('dragleave', (e) => this.handleDragLeave(e));
        this.uploadArea.addEventListener('drop', (e) => this.handleDrop(e));
        this.uploadArea.addEventListener('click', () => this.fileInput.click());

        // Generation button
        this.generateBtn.addEventListener('click', () => this.generateMCQs());

        // Results actions
        this.downloadBtn.addEventListener('click', () => this.downloadMCQs());
        this.newGenerationBtn.addEventListener('click', () => this.resetForNewGeneration());

        // History modal
        this.historyBtn.addEventListener('click', () => this.showHistory());
        this.closeHistoryModal.addEventListener('click', () => this.hideHistory());
        this.historyModal.addEventListener('click', (e) => {
            if (e.target === this.historyModal) this.hideHistory();
        });

        // Keyboard events
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.historyModal.style.display === 'block') {
                this.hideHistory();
            }
        });
    }

    handleDragOver(e) {
        e.preventDefault();
        this.uploadArea.classList.add('drag-over');
    }

    handleDragLeave(e) {
        e.preventDefault();
        this.uploadArea.classList.remove('drag-over');
    }

    handleDrop(e) {
        e.preventDefault();
        this.uploadArea.classList.remove('drag-over');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.handleFileSelect(files[0]);
        }
    }

    handleFileSelect(file) {
        if (!file) return;

        // Validate file type
        if (file.type !== 'application/pdf') {
            this.showToast('Please select a PDF file', 'error');
            return;
        }

        // Validate file size (10MB limit)
        const maxSize = 10 * 1024 * 1024; // 10MB in bytes
        if (file.size > maxSize) {
            this.showToast('File size must be less than 10MB', 'error');
            return;
        }

        this.currentFile = file;
        this.displayFileInfo(file);
        this.showConfigSection();
    }

    displayFileInfo(file) {
        this.fileName.textContent = file.name;
        this.fileSize.textContent = this.formatFileSize(file.size);
        
        this.uploadArea.style.display = 'none';
        this.fileInfo.style.display = 'flex';
    }

    removeFile() {
        this.currentFile = null;
        this.extractedText = '';
        
        this.fileInfo.style.display = 'none';
        this.uploadArea.style.display = 'block';
        this.configSection.style.display = 'none';
        this.hideResults();
    }

    showConfigSection() {
        this.configSection.style.display = 'block';
        this.configSection.scrollIntoView({ behavior: 'smooth' });
    }

    async generateMCQs() {
        if (!this.currentFile) {
            this.showToast('Please select a PDF file first', 'error');
            return;
        }

        try {
            this.showLoading();
            
            // Extract text from PDF
            this.updateLoadingText('Extracting text from PDF...');
            this.extractedText = await this.extractTextFromPDF(this.currentFile);
            
            if (!this.extractedText.trim()) {
                throw new Error('No text could be extracted from the PDF');
            }

            // Generate MCQs using OpenAI
            this.updateLoadingText('Generating MCQs with AI...');
            const result = await window.mcqGenerator.generateMCQs(
                this.extractedText,
                this.difficulty.value,
                parseInt(this.questionCount.value)
            );

            this.currentMCQs = result.mcqs;
            this.currentSummary = result.summary;

            // Save to history
            window.historyManager.addToHistory({
                fileName: this.currentFile.name,
                difficulty: this.difficulty.value,
                questionCount: parseInt(this.questionCount.value),
                mcqs: this.currentMCQs,
                summary: this.currentSummary,
                timestamp: new Date().toISOString()
            });

            this.displayResults();
            this.showToast('MCQs generated successfully!', 'success');
            
        } catch (error) {
            console.error('Error generating MCQs:', error);
            this.showToast(error.message || 'Failed to generate MCQs', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async extractTextFromPDF(file) {
        return new Promise((resolve, reject) => {
            const fileReader = new FileReader();
            
            fileReader.onload = async function() {
                try {
                    const typedArray = new Uint8Array(this.result);
                    const pdf = await pdfjsLib.getDocument({ data: typedArray }).promise;
                    let fullText = '';

                    for (let i = 1; i <= pdf.numPages; i++) {
                        const page = await pdf.getPage(i);
                        const textContent = await page.getTextContent();
                        const pageText = textContent.items
                            .map(item => item.str)
                            .join(' ');
                        fullText += pageText + '\n\n';
                    }

                    resolve(fullText.trim());
                } catch (error) {
                    reject(new Error('Failed to extract text from PDF: ' + error.message));
                }
            };

            fileReader.onerror = () => {
                reject(new Error('Failed to read PDF file'));
            };

            fileReader.readAsArrayBuffer(file);
        });
    }

    displayResults() {
        // Display summary
        this.documentSummary.textContent = this.currentSummary;

        // Display MCQs
        this.mcqsContainer.innerHTML = '';
        this.currentMCQs.forEach((mcq, index) => {
            const mcqElement = this.createMCQElement(mcq, index + 1);
            this.mcqsContainer.appendChild(mcqElement);
        });

        this.showResults();
    }

    createMCQElement(mcq, questionNumber) {
        const mcqCard = document.createElement('div');
        mcqCard.className = 'mcq-card';

        const questionElement = document.createElement('div');
        questionElement.className = 'mcq-question';
        questionElement.textContent = `${questionNumber}. ${mcq.question}`;

        const optionsContainer = document.createElement('div');
        optionsContainer.className = 'mcq-options';

        mcq.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'mcq-option';
            
            if (index === mcq.correct_answer) {
                optionElement.classList.add('correct');
            }

            const label = document.createElement('span');
            label.className = 'mcq-option-label';
            label.textContent = String.fromCharCode(65 + index) + '.';

            const text = document.createElement('span');
            text.textContent = option;

            optionElement.appendChild(label);
            optionElement.appendChild(text);
            optionsContainer.appendChild(optionElement);
        });

        mcqCard.appendChild(questionElement);
        mcqCard.appendChild(optionsContainer);

        return mcqCard;
    }

    downloadMCQs() {
        if (!this.currentMCQs) {
            this.showToast('No MCQs to download', 'error');
            return;
        }

        const content = this.formatMCQsForDownload();
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `MCQs_${this.currentFile.name.replace('.pdf', '')}_${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        this.showToast('MCQs downloaded successfully!', 'success');
    }

    formatMCQsForDownload() {
        let content = `MCQs Generated from: ${this.currentFile.name}\n`;
        content += `Generated on: ${new Date().toLocaleDateString()}\n`;
        content += `Difficulty: ${this.difficulty.value}\n`;
        content += `Number of questions: ${this.questionCount.value}\n\n`;
        content += `DOCUMENT SUMMARY:\n${this.currentSummary}\n\n`;
        content += `MULTIPLE CHOICE QUESTIONS:\n\n`;

        this.currentMCQs.forEach((mcq, index) => {
            content += `${index + 1}. ${mcq.question}\n`;
            mcq.options.forEach((option, optIndex) => {
                const marker = optIndex === mcq.correct_answer ? '* ' : '  ';
                content += `${marker}${String.fromCharCode(65 + optIndex)}. ${option}\n`;
            });
            content += `\nCorrect Answer: ${String.fromCharCode(65 + mcq.correct_answer)}\n\n`;
        });

        return content;
    }

    resetForNewGeneration() {
        this.removeFile();
        this.hideResults();
        this.hideLoading();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    showLoading() {
        this.loadingSection.style.display = 'block';
        this.configSection.style.display = 'none';
        this.hideResults();
        this.loadingSection.scrollIntoView({ behavior: 'smooth' });
    }

    hideLoading() {
        this.loadingSection.style.display = 'none';
        this.configSection.style.display = 'block';
    }

    updateLoadingText(text) {
        this.loadingText.textContent = text;
    }

    showResults() {
        this.resultsSection.style.display = 'block';
        this.hideLoading();
        this.resultsSection.scrollIntoView({ behavior: 'smooth' });
    }

    hideResults() {
        this.resultsSection.style.display = 'none';
    }

    showHistory() {
        const history = window.historyManager.getHistory();
        this.renderHistory(history);
        this.historyModal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }

    hideHistory() {
        this.historyModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    renderHistory(history) {
        this.historyList.innerHTML = '';

        if (history.length === 0) {
            const emptyState = document.createElement('div');
            emptyState.style.textAlign = 'center';
            emptyState.style.padding = '2rem';
            emptyState.style.color = 'var(--text-secondary)';
            emptyState.innerHTML = `
                <i data-feather="clock" style="width: 3rem; height: 3rem; margin-bottom: 1rem;"></i>
                <p>No generation history yet</p>
                <p style="font-size: 0.875rem;">Generate some MCQs to see them here</p>
            `;
            this.historyList.appendChild(emptyState);
            feather.replace();
            return;
        }

        history.forEach((item, index) => {
            const historyItem = this.createHistoryItem(item, index);
            this.historyList.appendChild(historyItem);
        });
        
        feather.replace();
    }

    createHistoryItem(item, index) {
        const historyItem = document.createElement('div');
        historyItem.className = 'history-item';

        const date = new Date(item.timestamp).toLocaleDateString();
        const time = new Date(item.timestamp).toLocaleTimeString();

        historyItem.innerHTML = `
            <div class="history-item-header">
                <div>
                    <div class="history-item-title">${item.fileName}</div>
                    <div class="history-item-date">${date} at ${time}</div>
                    <div class="history-item-config">
                        ${item.questionCount} questions • ${item.difficulty} difficulty
                    </div>
                </div>
                <div class="history-item-actions">
                    <button class="btn btn-outline" onclick="app.loadHistoryItem(${index})">
                        <i data-feather="eye"></i>
                        View
                    </button>
                    <button class="btn btn-outline" onclick="app.deleteHistoryItem(${index})">
                        <i data-feather="trash-2"></i>
                        Delete
                    </button>
                </div>
            </div>
        `;

        return historyItem;
    }

    loadHistoryItem(index) {
        const history = window.historyManager.getHistory();
        const item = history[index];
        
        if (item) {
            this.currentMCQs = item.mcqs;
            this.currentSummary = item.summary;
            this.displayResults();
            this.hideHistory();
            this.showToast('History item loaded successfully', 'success');
        }
    }

    deleteHistoryItem(index) {
        if (confirm('Are you sure you want to delete this history item?')) {
            window.historyManager.removeFromHistory(index);
            this.renderHistory(window.historyManager.getHistory());
            this.showToast('History item deleted', 'success');
        }
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;

        this.toastContainer.appendChild(toast);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.parentElement.removeChild(toast);
            }
        }, 5000);

        // Add click to dismiss
        toast.addEventListener('click', () => {
            if (toast.parentElement) {
                toast.parentElement.removeChild(toast);
            }
        });
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize theme manager
    window.themeManager = new ThemeManager();
    
    // Initialize history manager
    window.historyManager = new HistoryManager();
    
    // Initialize MCQ generator
    window.mcqGenerator = new MCQGenerator();
    
    // Initialize main app
    window.app = new MCQApp();
    
    // Replace Feather icons
    feather.replace();
});
