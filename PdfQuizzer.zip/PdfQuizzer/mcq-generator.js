// MCQ Generator using Google Gemini API (Free)
class MCQGenerator {
    constructor() {
        // Get API key from environment variable with fallback
        this.apiKey = this.getApiKey();
        this.baseURL = 'https://generativelanguage.googleapis.com/v1beta';
    }

    getApiKey() {
        // In browser environment, we'll use a server-side approach or localStorage
        // The GOOGLE_API_KEY will be injected by the server or build process
        let apiKey = null;
        
        // Try to get from a global variable (set by server)
        if (typeof window !== 'undefined' && window.GOOGLE_API_KEY) {
            apiKey = window.GOOGLE_API_KEY;
        }
        
        // Fallback to localStorage or prompt
        if (!apiKey) {
            apiKey = localStorage.getItem('gemini_api_key') || 
                     prompt('Please enter your Google Gemini API key (get free at ai.google.dev):');
        }
            
        if (!apiKey) {
            throw new Error('Google Gemini API key is required. Get a free key at https://ai.google.dev');
        }
        
        // Store for future use
        localStorage.setItem('gemini_api_key', apiKey);
        return apiKey;
    }

    async generateMCQs(text, difficulty, questionCount) {
        if (!text || text.trim().length === 0) {
            throw new Error('No text provided for MCQ generation');
        }

        if (!this.apiKey) {
            throw new Error('OpenAI API key is not configured');
        }

        try {
            // First, generate a summary of the document
            const summary = await this.generateSummary(text);
            
            // Then generate MCQs
            const mcqs = await this.generateQuestions(text, difficulty, questionCount);
            
            return {
                summary,
                mcqs
            };
        } catch (error) {
            console.error('Error in MCQ generation:', error);
            throw new Error(`Failed to generate MCQs: ${error.message}`);
        }
    }

    async generateSummary(text) {
        const prompt = `Please provide a concise summary of the following document content in 2-3 sentences. Focus on the main topics and key concepts:\n\n${text.substring(0, 8000)}`;

        try {
            const response = await this.makeGeminiRequest(prompt);
            return response.trim();
        } catch (error) {
            console.error('Error generating summary:', error);
            return 'Summary generation failed. Please try again.';
        }
    }

    async generateQuestions(text, difficulty, questionCount) {
        const difficultyInstructions = {
            easy: "Create easy questions that test basic understanding and recall of information. Questions should be straightforward and test fundamental concepts.",
            medium: "Create medium difficulty questions that test comprehension and application of concepts. Questions should require some analysis and understanding.",
            hard: "Create challenging questions that test analysis, synthesis, and evaluation. Questions should require critical thinking and deep understanding."
        };

        const prompt = `Generate exactly ${questionCount} multiple choice questions based on the following text. 

DIFFICULTY LEVEL: ${difficulty.toUpperCase()}
${difficultyInstructions[difficulty]}

REQUIREMENTS:
- Each question must have exactly 4 options (A, B, C, D)
- Only one option should be correct
- Questions should be clear and unambiguous
- Options should be plausible but only one correct
- Cover different parts of the content
- Questions should be relevant to the main topics

TEXT TO ANALYZE:
${text.substring(0, 12000)}

Please respond with a JSON object containing an array called "questions" where each question has:
- "question": the question text
- "options": array of 4 strings (the answer choices)
- "correct_answer": number (0-3 indicating which option is correct)
- "explanation": brief explanation of why the answer is correct

Example format:
{
  "questions": [
    {
      "question": "What is the main topic discussed?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct_answer": 1,
      "explanation": "Option B is correct because..."
    }
  ]
}`;

        try {
            const systemPrompt = `You are an expert educational content creator specializing in creating high-quality multiple choice questions. Always respond with valid JSON format.

${prompt}`;

            const response = await this.makeGeminiRequest(systemPrompt);
            const result = JSON.parse(response);
            
            if (!result.questions || !Array.isArray(result.questions)) {
                throw new Error('Invalid response format from OpenAI');
            }

            // Validate and clean the questions
            const validatedQuestions = this.validateQuestions(result.questions, questionCount);
            
            return validatedQuestions;
        } catch (error) {
            console.error('Error generating questions:', error);
            throw new Error(`Failed to generate questions: ${error.message}`);
        }
    }

    validateQuestions(questions, expectedCount) {
        const validQuestions = [];

        for (const question of questions) {
            // Validate question structure
            if (!question.question || !question.options || !Array.isArray(question.options)) {
                console.warn('Skipping invalid question:', question);
                continue;
            }

            // Ensure exactly 4 options
            if (question.options.length !== 4) {
                console.warn('Question does not have exactly 4 options:', question);
                continue;
            }

            // Validate correct answer index
            if (typeof question.correct_answer !== 'number' || 
                question.correct_answer < 0 || 
                question.correct_answer > 3) {
                console.warn('Invalid correct_answer index:', question);
                continue;
            }

            // Clean up the question
            const cleanQuestion = {
                question: question.question.trim(),
                options: question.options.map(opt => opt.trim()),
                correct_answer: question.correct_answer,
                explanation: question.explanation ? question.explanation.trim() : ''
            };

            validQuestions.push(cleanQuestion);

            // Stop if we have enough questions
            if (validQuestions.length >= expectedCount) {
                break;
            }
        }

        if (validQuestions.length === 0) {
            throw new Error('No valid questions could be generated from the response');
        }

        if (validQuestions.length < expectedCount) {
            console.warn(`Only generated ${validQuestions.length} out of ${expectedCount} requested questions`);
        }

        return validQuestions;
    }

    async makeGeminiRequest(prompt) {
        const url = `${this.baseURL}/models/gemini-2.0-flash-exp:generateContent?key=${this.apiKey}`;
        
        const requestBody = {
            contents: [
                {
                    parts: [
                        {
                            text: prompt
                        }
                    ]
                }
            ],
            generationConfig: {
                temperature: 0.4,
                topK: 32,
                topP: 1,
                maxOutputTokens: 3000,
            }
        };

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            const errorMessage = errorData.error?.message || `HTTP ${response.status}: ${response.statusText}`;
            
            if (response.status === 401) {
                throw new Error('Invalid Google Gemini API key. Get a free key at https://ai.google.dev');
            } else if (response.status === 429) {
                throw new Error('Gemini API rate limit exceeded. Please try again in a moment.');
            } else if (response.status === 400) {
                throw new Error('Invalid request format. Please try again.');
            } else {
                throw new Error(`Gemini API error: ${errorMessage}`);
            }
        }

        const data = await response.json();
        
        if (!data.candidates || data.candidates.length === 0) {
            throw new Error('No response generated from Gemini API');
        }

        return data.candidates[0].content.parts[0].text;
    }

    // Method to test API key validity
    async testApiKey() {
        try {
            const response = await this.makeGeminiRequest("Say 'API key is working' if you can read this.");
            return response.includes('working');
        } catch (error) {
            console.error('API key test failed:', error);
            return false;
        }
    }

    // Method to update API key
    updateApiKey(newApiKey) {
        this.apiKey = newApiKey;
        if (typeof localStorage !== 'undefined') {
            localStorage.setItem('gemini_api_key', newApiKey);
        }
    }
}
