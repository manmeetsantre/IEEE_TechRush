#!/usr/bin/env python3
import os
import http.server
import socketserver
from urllib.parse import urlparse
import mimetypes

class MCQServerHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        # Parse the URL
        parsed_path = urlparse(self.path)
        
        # If requesting the root or index.html, inject environment variables
        if parsed_path.path in ['/', '/index.html']:
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            # Read the HTML file
            with open('index.html', 'r', encoding='utf-8') as f:
                html_content = f.read()
            
            # Inject the Google API key
            google_api_key = os.environ.get('GOOGLE_API_KEY', '')
            html_content = html_content.replace(
                "window.GOOGLE_API_KEY = '<!-- GOOGLE_API_KEY will be injected here -->';",
                f"window.GOOGLE_API_KEY = '{google_api_key}';"
            )
            
            # Send the modified HTML
            self.wfile.write(html_content.encode('utf-8'))
        else:
            # For all other files, serve normally
            super().do_GET()

def run_server(port=5000):
    """Run the MCQ Generator server with environment variable injection"""
    
    # Change to the directory containing the files
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Create server
    with socketserver.TCPServer(("0.0.0.0", port), MCQServerHandler) as httpd:
        print(f"MCQ Generator server running at http://0.0.0.0:{port}")
        print(f"Google API Key available: {'Yes' if os.environ.get('GOOGLE_API_KEY') else 'No'}")
        httpd.serve_forever()

if __name__ == "__main__":
    run_server()