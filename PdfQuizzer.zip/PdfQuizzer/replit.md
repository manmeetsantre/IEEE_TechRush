# MCQ Generator

## Overview

MCQ Generator is a web-based application that automatically generates multiple-choice questions from PDF documents using OpenAI's API. Users can upload PDF files, extract text content, and generate customizable MCQs with different difficulty levels and question counts. The application features a modern, responsive interface with dark/light theme support and maintains a history of generated MCQs for easy access.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Pure Vanilla JavaScript**: No frameworks used, promoting simplicity and direct DOM manipulation
- **Modular Class-Based Design**: Separate classes for different concerns (MCQApp, MCQGenerator, HistoryManager, ThemeManager)
- **Component Separation**: Each major feature is isolated in its own JavaScript file for maintainability
- **Responsive CSS**: Modern CSS with CSS variables for theming and responsive design patterns

### PDF Processing
- **Client-Side PDF Parsing**: Uses PDF.js library (v3.11.174) from CDN for extracting text from uploaded PDFs
- **File Size Limits**: Maximum 10MB PDF file size to prevent performance issues
- **Browser-Based Processing**: All PDF text extraction happens in the browser without server dependency

### AI Integration
- **Google Gemini API Integration**: Direct API calls to Google's free Gemini model for MCQ generation and document summarization
- **Free API Usage**: Uses Google Gemini 2.0 Flash with generous free tier - no credits required
- **Flexible API Key Management**: Supports localStorage and user prompt for API key input
- **Two-Stage Generation**: First generates document summary, then creates MCQs based on extracted text
- **Advanced AI Model**: Uses gemini-2.0-flash-exp for high-quality text processing and question generation

### Data Storage
- **LocalStorage-Based History**: Stores generation history locally in browser storage
- **No Database Required**: Eliminates need for backend database infrastructure
- **History Management**: Automatic pruning to 50 items to prevent localStorage overflow
- **Structured Data Format**: JSON-based storage with metadata (timestamps, file info, processing time)

### User Interface Design
- **Theme Management**: Built-in dark/light theme toggle with system preference detection
- **Progressive Enhancement**: Features degrade gracefully if JavaScript is disabled
- **Modern UI Elements**: Uses Feather Icons for consistent iconography
- **Modal-Based History**: Non-intrusive history viewing with modal interface

### State Management
- **In-Memory State**: Current file, extracted text, and generated MCQs stored in application instance
- **Persistent Preferences**: Theme preferences and history maintained across sessions
- **Event-Driven Architecture**: Loose coupling between components through event listeners

## External Dependencies

### Core Libraries
- **PDF.js (v3.11.174)**: Mozilla's PDF parsing library loaded from CDN for client-side PDF text extraction
- **Feather Icons**: Lightweight icon library loaded from unpkg CDN for UI iconography
- **Direct API Integration**: Uses fetch API for direct communication with Google's Gemini service

### APIs and Services
- **Google Gemini API**: Primary service for generating MCQs and document summaries using free Gemini models
- **Browser APIs**: FileReader API for file handling, localStorage for data persistence, matchMedia for theme detection

### Development Dependencies
- **No Build Tools**: Application runs directly in browser without compilation or bundling
- **No Server Requirements**: Fully client-side application with no backend infrastructure needed
- **CDN Dependencies**: All external libraries loaded from reliable CDNs to minimize setup complexity

### Browser Compatibility
- **Modern Browser Requirements**: Requires ES6+ features (classes, async/await, arrow functions)
- **Local Storage Support**: Essential for history and theme persistence
- **File API Support**: Required for PDF file handling and processing