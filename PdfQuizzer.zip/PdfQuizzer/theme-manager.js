// Theme Management
class ThemeManager {
    constructor() {
        this.currentTheme = this.getStoredTheme() || this.getSystemTheme();
        this.themeToggle = document.getElementById('themeToggle');
        
        this.initializeTheme();
        this.attachEventListeners();
    }

    initializeTheme() {
        this.applyTheme(this.currentTheme);
    }

    attachEventListeners() {
        if (this.themeToggle) {
            this.themeToggle.addEventListener('click', () => {
                this.toggleTheme();
            });
        }

        // Listen for system theme changes
        if (window.matchMedia) {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
            mediaQuery.addEventListener('change', (e) => {
                // Only auto-switch if user hasn't manually set a preference
                if (!this.getStoredTheme()) {
                    this.applyTheme(e.matches ? 'dark' : 'light');
                }
            });
        }
    }

    getSystemTheme() {
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            return 'dark';
        }
        return 'light';
    }

    getStoredTheme() {
        try {
            return localStorage.getItem('theme');
        } catch (error) {
            console.warn('Unable to access localStorage for theme preference');
            return null;
        }
    }

    storeTheme(theme) {
        try {
            localStorage.setItem('theme', theme);
        } catch (error) {
            console.warn('Unable to store theme preference in localStorage');
        }
    }

    applyTheme(theme) {
        this.currentTheme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        this.updateThemeToggleIcon();
        this.storeTheme(theme);
    }

    toggleTheme() {
        const newTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
        this.applyTheme(newTheme);
        
        // Add a subtle animation feedback
        this.animateToggle();
    }

    updateThemeToggleIcon() {
        if (!this.themeToggle) return;

        const lightIcon = this.themeToggle.querySelector('.light-icon');
        const darkIcon = this.themeToggle.querySelector('.dark-icon');

        if (this.currentTheme === 'dark') {
            if (lightIcon) lightIcon.style.display = 'none';
            if (darkIcon) darkIcon.style.display = 'block';
        } else {
            if (lightIcon) lightIcon.style.display = 'block';
            if (darkIcon) darkIcon.style.display = 'none';
        }
    }

    animateToggle() {
        if (!this.themeToggle) return;

        // Add animation class
        this.themeToggle.style.transform = 'rotate(180deg)';
        
        // Reset animation after completion
        setTimeout(() => {
            this.themeToggle.style.transform = '';
        }, 300);
    }

    // Public method to get current theme
    getCurrentTheme() {
        return this.currentTheme;
    }

    // Public method to set theme programmatically
    setTheme(theme) {
        if (theme === 'light' || theme === 'dark') {
            this.applyTheme(theme);
        } else {
            console.warn('Invalid theme specified. Use "light" or "dark".');
        }
    }

    // Method to reset to system preference
    resetToSystemTheme() {
        const systemTheme = this.getSystemTheme();
        this.applyTheme(systemTheme);
        
        // Remove stored preference to follow system changes
        try {
            localStorage.removeItem('theme');
        } catch (error) {
            console.warn('Unable to remove theme preference from localStorage');
        }
    }
}

// CSS custom property updates for smooth transitions
document.addEventListener('DOMContentLoaded', () => {
    // Add transition styles for theme switching
    const style = document.createElement('style');
    style.textContent = `
        * {
            transition: background-color 0.3s ease, 
                       color 0.3s ease, 
                       border-color 0.3s ease,
                       box-shadow 0.3s ease;
        }
        
        .theme-toggle {
            transition: transform 0.3s ease, 
                       background-color 0.3s ease,
                       border-color 0.3s ease;
        }
        
        /* Reduce motion for users who prefer it */
        @media (prefers-reduced-motion: reduce) {
            * {
                transition: none !important;
            }
        }
    `;
    document.head.appendChild(style);
});
